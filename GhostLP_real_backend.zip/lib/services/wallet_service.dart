import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:solana_kit_mobile_wallet_adapter/solana_kit_mobile_wallet_adapter.dart';
import 'package:solana_kit_mobile_wallet_adapter_protocol/solana_kit_mobile_wallet_adapter_protocol.dart';
import '../config.dart';

/// Wallet state for GhostLP.
///
/// We persist only the MWA authorization token and public address.
/// Private keys never enter the app or its storage.
class WalletService extends ChangeNotifier {
  static const _tokenKey = 'ghostlp.mwa.auth_token';
  static const _addressKey = 'ghostlp.wallet.address';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  String? _address;
  String? _authToken;
  bool _connecting = false;
  bool _restoring = true;
  String? _error;
  LocalAssociationScenario? _scenario;
  dynamic _mwa;

  String? get address => _address;
  String? get authToken => _authToken;
  bool get connected => _address != null;
  bool get connecting => _connecting;
  bool get restoring => _restoring;
  String? get error => _error;

  Future<void> restore() async {
    _restoring = true;
    _error = null;
    notifyListeners();
    try {
      _authToken = await _secure.read(key: _tokenKey);
      final savedAddress = await _secure.read(key: _addressKey);
      if (_authToken == null || savedAddress == null) {
        _clearMemory();
        return;
      }

      final scenario = LocalAssociationScenario();
      _scenario = scenario;
      final raw = await scenario.start();
      _mwa = wrapWithKitApi(raw);

      final result = await _mwa.authorize(
        identity: const AppIdentity(
          name: Config.appName,
          uri: Config.appUri,
        ),
        chain: 'solana:mainnet',
        authToken: _authToken,
      );

      final accounts = result.accounts;
      if (accounts.isEmpty) {
        throw StateError('Wallet returned no authorized accounts.');
      }
      _authToken = result.authToken;
      _address = _readAddress(accounts.first.address);
      await _persist();
    } catch (_) {
      // A revoked/expired MWA token is not an app error. It simply means the
      // user needs to approve a fresh connection.
      await _closeScenario();
      _clearMemory();
    } finally {
      _restoring = false;
      notifyListeners();
    }
  }

  Future<void> connect() async {
    if (_connecting) return;
    _connecting = true;
    _error = null;
    notifyListeners();
    try {
      await _closeScenario();
      final scenario = LocalAssociationScenario();
      _scenario = scenario;
      final raw = await scenario.start();
      _mwa = wrapWithKitApi(raw);

      final result = await _mwa.authorize(
        identity: const AppIdentity(
          name: Config.appName,
          uri: Config.appUri,
        ),
        chain: 'solana:mainnet',
      );
      if (result.accounts.isEmpty) {
        throw StateError('No wallet account was returned.');
      }

      _authToken = result.authToken;
      _address = _readAddress(result.accounts.first.address);
      await _persist();
    } catch (e) {
      _error = e.toString();
      await _closeScenario();
    } finally {
      _connecting = false;
      notifyListeners();
    }
  }

  Future<dynamic> signAndSend(String base64Transaction) async {
    if (_mwa == null || _authToken == null) {
      throw StateError('Wallet session is not active.');
    }
    final result = await _mwa.signAndSendTransactions(
      transactions: [base64Transaction],
    );
    return result;
  }

  Future<void> disconnect() async {
    try {
      if (_mwa != null && _authToken != null) {
        await _mwa.deauthorize(authToken: _authToken);
      }
    } catch (_) {
      // Local state must still be cleared if the wallet app is unavailable.
    }
    await _closeScenario();
    await _secure.delete(key: _tokenKey);
    await _secure.delete(key: _addressKey);
    _clearMemory();
    notifyListeners();
  }

  String _readAddress(dynamic value) {
    // The current Kit API exposes account addresses as strings. Keep this
    // defensive for protocol implementations that expose a byte wrapper.
    if (value is String) return value;
    return '$value';
  }

  Future<void> _persist() async {
    if (_authToken != null) {
      await _secure.write(key: _tokenKey, value: _authToken);
    }
    if (_address != null) {
      await _secure.write(key: _addressKey, value: _address);
    }
  }

  void _clearMemory() {
    _authToken = null;
    _address = null;
  }

  Future<void> _closeScenario() async {
    try {
      await _scenario?.close();
    } catch (_) {}
    _scenario = null;
    _mwa = null;
  }
}
