import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:solana_kit_mobile_wallet_adapter/solana_kit_mobile_wallet_adapter.dart';
import 'package:solana_kit_mobile_wallet_adapter_protocol/solana_kit_mobile_wallet_adapter_protocol.dart';
import '../config.dart';

/// Wallet state for GhostLP.
///
/// Only the MWA authorization token and public address are persisted.
/// Private keys never enter the app or its storage.
class WalletService extends ChangeNotifier {
  static const _tokenKey = 'ghostlp.mwa.auth_token';
  static const _addressKey = 'ghostlp.wallet.address';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  String? _address;
  String? _authToken;
  bool _connecting = false;
  bool _restoring = true;
  String? _error;
  LocalAssociationScenario? _scenario;
  dynamic _mwa;

  String? get address => _address;
  String? get authToken => _authToken;
  bool get connected => _address != null && _authToken != null;
  bool get connecting => _connecting;
  bool get restoring => _restoring;
  String? get error => _error;

  /// Restore the local connection state without opening the wallet app.
  ///
  /// MWA authorization tokens are specifically intended to be stored and
  /// reused on later sessions. We keep the UI connected after an app restart,
  /// then create a fresh MWA transport only when a wallet operation is needed.
  /// This avoids launching/associating with the wallet during app startup.
  Future<void> restore() async {
    _restoring = true;
    _error = null;
    notifyListeners();
    try {
      final token = await _secure.read(key: _tokenKey);
      final savedAddress = await _secure.read(key: _addressKey);

      if (token == null || token.isEmpty || savedAddress == null || savedAddress.isEmpty) {
        _clearMemory();
      } else {
        _authToken = token;
        _address = savedAddress;
      }
    } catch (e) {
      _clearMemory();
      _error = 'Could not restore wallet session: $e';
    } finally {
      _restoring = false;
      notifyListeners();
    }
  }

  /// Connects or refreshes the MWA authorization.
  ///
  /// If a saved token exists, try silent re-authorization first. If the
  /// wallet has revoked/expired it, discard that token and request a fresh
  /// authorization in the same user-initiated flow.
  Future<void> connect() async {
    if (_connecting) return;
    _connecting = true;
    _error = null;
    notifyListeners();

    try {
      await _closeScenario();

      if (_authToken != null && _authToken!.isNotEmpty) {
        try {
          await _startSession();
          final result = await _mwa.authorize(
            identity: AppIdentity(
              name: Config.appName,
              uri: Uri.parse(Config.appUri),
            ),
            chain: 'solana:mainnet',
            authToken: _authToken,
          );
          await _acceptAuthorization(result);
          return;
        } catch (_) {
          await _closeScenario();
          await _secure.delete(key: _tokenKey);
          await _secure.delete(key: _addressKey);
          _clearMemory();
        }
      }

      await _startSession();
      final result = await _mwa.authorize(
        identity: AppIdentity(
          name: Config.appName,
          uri: Uri.parse(Config.appUri),
        ),
        chain: 'solana:mainnet',
      );
      await _acceptAuthorization(result);
    } catch (e) {
      _error = e.toString();
      await _closeScenario();
    } finally {
      _connecting = false;
      notifyListeners();
    }
  }

  /// Opens a fresh MWA transport and silently re-authorizes with the saved
  /// token. If the token is no longer valid, asks for a new authorization.
  Future<void> _ensureAuthorizedSession() async {
    await _closeScenario();
    await _startSession();

    try {
      final result = await _mwa.authorize(
        identity: AppIdentity(
          name: Config.appName,
          uri: Uri.parse(Config.appUri),
        ),
        chain: 'solana:mainnet',
        authToken: _authToken,
      );
      await _acceptAuthorization(result);
    } catch (_) {
      await _closeScenario();
      await _startSession();
      final result = await _mwa.authorize(
        identity: AppIdentity(
          name: Config.appName,
          uri: Uri.parse(Config.appUri),
        ),
        chain: 'solana:mainnet',
      );
      await _acceptAuthorization(result);
    }
  }

  Future<void> _startSession() async {
    final scenario = LocalAssociationScenario();
    _scenario = scenario;
    final raw = await scenario.start();
    _mwa = wrapWithKitApi(raw);
  }

  Future<void> _acceptAuthorization(dynamic result) async {
    final accounts = result.accounts;
    if (accounts.isEmpty) {
      throw StateError('Wallet returned no authorized accounts.');
    }

    final nextToken = result.authToken;
    if (nextToken == null || '$nextToken'.isEmpty) {
      throw StateError('Wallet returned no authorization token.');
    }

    _authToken = '$nextToken';
    _address = _readAddress(accounts.first.address);
    await _persist();
    notifyListeners();
  }

  /// Signs and sends using a fresh MWA session for this operation.
  /// The session is closed afterward; the persisted authorization token stays
  /// available for the next operation and for the next app launch.
  Future<dynamic> signAndSend(String base64Transaction) async {
    if (_authToken == null || _address == null) {
      throw StateError('Wallet is not connected.');
    }

    try {
      await _ensureAuthorizedSession();
      return await _mwa.signAndSendTransactions(
        transactions: [base64Transaction],
      );
    } finally {
      await _closeScenario();
    }
  }

  Future<void> disconnect() async {
    try {
      if (_mwa != null && _authToken != null) {
        await _mwa.deauthorize(authToken: _authToken);
      }
    } catch (_) {
      // Local state must still be cleared if the wallet app is unavailable.
    }
    await _closeScenario();
    await _secure.delete(key: _tokenKey);
    await _secure.delete(key: _addressKey);
    _clearMemory();
    notifyListeners();
  }

  String _readAddress(dynamic value) {
    if (value is String) return value;
    return '$value';
  }

  Future<void> _persist() async {
    if (_authToken != null) {
      await _secure.write(key: _tokenKey, value: _authToken);
    }
    if (_address != null) {
      await _secure.write(key: _addressKey, value: _address);
    }
  }

  void _clearMemory() {
    _authToken = null;
    _address = null;
  }

  Future<void> _closeScenario() async {
    try {
      await _scenario?.close();
    } catch (_) {}
    _scenario = null;
    _mwa = null;
  }
}
