# GhostLP

Premium Flutter Solana liquidity app with secure Mobile Wallet Adapter sessions and a transaction-building backend.

## Backend

The backend now builds **unsigned Raydium CPMM transactions** for:

- pool creation
- add liquidity
- remove liquidity

The backend never receives or stores a user's private key. The Flutter wallet remains the signer.

### Run

```bash
cd backend
cp .env.example .env
npm install
npm start
```

For Android emulator, the Flutter default backend URL is `http://10.0.2.2:8787`.

For a physical phone, pass the computer's LAN URL when running Flutter:

```bash
flutter run --dart-define=BACKEND_URL=http://YOUR_COMPUTER_IP:8787
```

## Raydium notes

The backend uses the current Raydium SDK V2 CPMM builders. Raydium's SDK requires the wallet owner public key while constructing owner-specific accounts; GhostLP supplies only that public key to the builder and never calls the SDK's signing/execution path.

## Orca

The UI retains Orca selection, but this backend deliberately returns a clear 501 for Orca transaction construction until the current Whirlpools SDK is wired and tested against the exact pool parameters used by the UI. Do not treat an Orca transaction as supported yet.

## Security

Never put a seed phrase, private key, or wallet secret into `.env`, the backend, Flutter storage, logs, or API requests.
