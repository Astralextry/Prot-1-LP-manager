import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';

class BackendService {
  final http.Client _client;
  BackendService({http.Client? client}) : _client = client ?? http.Client();

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final r = await _client
        .post(
          Uri.parse('${Config.backendUrl}$path'),
          headers: {'content-type': 'application/json'},
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 25));

    Map<String, dynamic> data = {};
    try {
      final decoded = jsonDecode(r.body);
      if (decoded is Map) data = Map<String, dynamic>.from(decoded);
    } catch (_) {}

    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(data['error'] ?? 'Backend error (${r.statusCode})');
    }
    return data;
  }

  Future<Map<String, dynamic>> buildCreatePool({
    required String wallet,
    required String dex,
    required String mintA,
    required String mintB,
    required String amountA,
    required String amountB,
    required String feeTier,
    int? startTime,
  }) =>
      _post('/v1/pools/create', {
        'wallet': wallet,
        'dex': dex,
        'mintA': mintA,
        'mintB': mintB,
        'amountA': amountA,
        'amountB': amountB,
        'feeTier': feeTier,
        'startTime': startTime,
      });

  Future<Map<String, dynamic>> buildAddLiquidity({
    required String wallet,
    required String dex,
    required String poolId,
    required String amountA,
    required String amountB,
  }) =>
      _post('/v1/liquidity/add', {
        'wallet': wallet,
        'dex': dex,
        'poolId': poolId,
        'amountA': amountA,
        'amountB': amountB,
      });

  Future<Map<String, dynamic>> buildRemoveLiquidity({
    required String wallet,
    required String dex,
    required String poolId,
    required int percent,
  }) =>
      _post('/v1/liquidity/remove', {
        'wallet': wallet,
        'dex': dex,
        'poolId': poolId,
        'percent': percent,
      });
}
