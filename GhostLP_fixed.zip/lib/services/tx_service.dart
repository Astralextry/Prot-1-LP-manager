import 'package:flutter/foundation.dart';
import 'backend_service.dart';
import 'wallet_service.dart';

/// Transaction coordinator.
///
/// The backend creates an unsigned transaction; the wallet signs and sends it.
/// GhostLP never receives or stores a seed phrase/private key.
class TxService {
  final WalletService wallet;
  final BackendService backend;
  TxService(this.wallet, {BackendService? backend})
      : backend = backend ?? BackendService();

  Future<String> _signBuilt(Map<String, dynamic> result) async {
    final tx = result['transaction'];
    if (tx is! String || tx.isEmpty) {
      throw StateError('Backend did not return an unsigned transaction.');
    }
    final sendResult = await wallet.signAndSend(tx);

    if (sendResult is String) return sendResult;
    if (sendResult is List && sendResult.isNotEmpty) return '${sendResult.first}';
    if (sendResult is Map && sendResult['signatures'] is List) {
      final signatures = sendResult['signatures'] as List;
      if (signatures.isNotEmpty) return '${signatures.first}';
    }
    return '$sendResult';
  }

  Future<String> createPool({
    required String dex,
    required String mintA,
    required String mintB,
    required String amountA,
    required String amountB,
    required String feeTier,
    int? startTime,
  }) async {
    final address = wallet.address;
    if (address == null) throw StateError('Connect your wallet first.');
    final result = await backend.buildCreatePool(
      wallet: address,
      dex: dex,
      mintA: mintA,
      mintB: mintB,
      amountA: amountA,
      amountB: amountB,
      feeTier: feeTier,
      startTime: startTime,
    );
    return _signBuilt(result);
  }

  Future<String> addLiquidity({
    required String dex,
    required String poolId,
    required String amountA,
    required String amountB,
  }) async {
    final address = wallet.address;
    if (address == null) throw StateError('Connect your wallet first.');
    final result = await backend.buildAddLiquidity(
      wallet: address,
      dex: dex,
      poolId: poolId,
      amountA: amountA,
      amountB: amountB,
    );
    return _signBuilt(result);
  }

  Future<String> removeLiquidity({
    required String dex,
    required String poolId,
    required int percent,
  }) async {
    final address = wallet.address;
    if (address == null) throw StateError('Connect your wallet first.');
    final result = await backend.buildRemoveLiquidity(
      wallet: address,
      dex: dex,
      poolId: poolId,
      percent: percent,
    );
    return _signBuilt(result);
  }
}
