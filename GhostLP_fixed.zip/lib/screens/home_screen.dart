import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/balance_service.dart';
import '../services/wallet_service.dart';
import '../widgets/connect_button.dart';
import '../widgets/ghost_logo.dart';

class HomeScreen extends StatefulWidget {
  final WalletService wallet;
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.wallet, required this.goTab});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final svc = BalanceService();
  Portfolio? portfolio;
  String? error, _loadedFor;
  bool loading = false;
  @override void initState() { super.initState(); widget.wallet.addListener(_maybeLoad); _maybeLoad(); }
  @override void dispose() { widget.wallet.removeListener(_maybeLoad); super.dispose(); }
  void _maybeLoad() {
    final a=widget.wallet.address;
    if(a==_loadedFor) return;
    _loadedFor=a;
    if(a==null) { if(mounted)setState(()=>portfolio=null); } else { _refresh(); }
  }
  Future<void> _refresh() async {
    final a=widget.wallet.address; if(a==null)return;
    if(mounted)setState(()=>loading=true);
    try { portfolio=await svc.load(a); error=null; } catch(e){ error='$e'; }
    if(mounted)setState(()=>loading=false);
  }
  String _money(double v)=>'\$${v.toStringAsFixed(2).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'),(m)=>',')}';

  @override Widget build(BuildContext context) {
    final addr=widget.wallet.address;
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          if(addr==null) ...[
            const SizedBox(height: 48),
            const Center(child: GhostLogo(size: 72)),
            const SizedBox(height: 20),
            const Text('Welcome to GhostLP',textAlign:TextAlign.center,style:TextStyle(fontSize:28,fontWeight:FontWeight.w800,letterSpacing:-.8)),
            const SizedBox(height: 8),
            const Text('Manage liquidity across Solana with a clean, wallet-first experience.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white54,height:1.45)),
            const SizedBox(height: 26),
            Center(child:ConnectButton(wallet:widget.wallet)),
            const SizedBox(height: 14),
            const Text('Your wallet stays in control. GhostLP never asks for your seed phrase.',textAlign:TextAlign.center,style:TextStyle(color:Colors.white30,fontSize:12)),
          ] else ...[
            Row(children:[
              Container(width:38,height:38,decoration:BoxDecoration(color:const Color(0xFF1A1725),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.account_balance_wallet_rounded,color:Color(0xFFAB9FF2),size:19)),
              const SizedBox(width:10),
              Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const Text('Connected wallet',style:TextStyle(color:Colors.white38,fontSize:11)),
                Text('${addr.substring(0,5)}...${addr.substring(addr.length-5)}',style:const TextStyle(fontWeight:FontWeight.w700)),
              ]),
              const Spacer(),
              IconButton(onPressed:_refresh,icon:const Icon(Icons.refresh_rounded)),
            ]),
            const SizedBox(height:20),
            Container(
              padding:const EdgeInsets.fromLTRB(20,22,20,20),
              decoration:BoxDecoration(
                gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF191622),Color(0xFF100F15)]),
                borderRadius:BorderRadius.circular(24),
                border:Border.all(color:const Color(0xFF272331)),
              ),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                const Text('Portfolio value',style:TextStyle(color:Colors.white38,fontSize:13)),
                const SizedBox(height:8),
                AnimatedSwitcher(duration:const Duration(milliseconds:300),child:loading&&portfolio==null
                  ? const SizedBox(height:52,child:Align(alignment:Alignment.centerLeft,child:CircularProgressIndicator(strokeWidth:2)))
                  : Text(_money(portfolio?.total??0),key:ValueKey(portfolio?.total),style:const TextStyle(fontSize:42,fontWeight:FontWeight.w800,letterSpacing:-1.4))),
                if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.redAccent,fontSize:12))),
              ]),
            ),
            const SizedBox(height:18),
            Row(children:[
              _Action(Icons.qr_code_2_rounded,'Receive',()=>_receive(addr)),
              _Action(Icons.water_drop_rounded,'Pools',()=>widget.goTab(1)),
              _Action(Icons.add_circle_rounded,'Create',()=>widget.goTab(2)),
            ]),
            const SizedBox(height:26),
            Row(children:[const Text('Assets',style:TextStyle(fontSize:19,fontWeight:FontWeight.w800)),const Spacer(),Text('${portfolio?.holdings.length??0}',style:const TextStyle(color:Colors.white30))]),
            const SizedBox(height:10),
            for(final h in portfolio?.holdings??const <Holding>[])
              Container(
                margin:const EdgeInsets.only(bottom:8),
                padding:const EdgeInsets.all(14),
                decoration:BoxDecoration(color:const Color(0xFF111117),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFF1D1D26))),
                child:Row(children:[
                  Container(width:42,height:42,alignment:Alignment.center,decoration:BoxDecoration(color:const Color(0xFF1C1930),borderRadius:BorderRadius.circular(14)),child:Text(h.symbol.isEmpty?'?':h.symbol[0],style:const TextStyle(color:Color(0xFFAB9FF2),fontWeight:FontWeight.w800))),
                  const SizedBox(width:12),
                  Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(h.symbol,style:const TextStyle(fontWeight:FontWeight.w700)),Text('${h.amount.toStringAsFixed(h.amount<1?4:2)} ${h.symbol}',style:const TextStyle(color:Color(0x59FFFFFF),fontSize:12))])),
                  Text(_money(h.usd),style:const TextStyle(fontWeight:FontWeight.w700)),
                ]),
              ),
          ],
        ],
      ),
    );
  }
  void _receive(String addr)=>showModalBottomSheet(context:context,showDragHandle:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(20,8,20,24),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Text('Your Solana address',style:TextStyle(fontWeight:FontWeight.w800,fontSize:20)),const SizedBox(height:12),
    SelectableText(addr,textAlign:TextAlign.center,style:const TextStyle(color:Colors.white70)),const SizedBox(height:16),
    SizedBox(width:double.infinity,child:FilledButton.icon(icon:const Icon(Icons.copy_rounded),label:const Text('Copy address'),onPressed:(){Clipboard.setData(ClipboardData(text:addr));Navigator.pop(ctx);})),
  ]))));
}
class _Action extends StatelessWidget{
  final IconData icon;final String label;final VoidCallback onTap;
  const _Action(this.icon,this.label,this.onTap);
  @override Widget build(BuildContext context)=>Expanded(child:Padding(padding:const EdgeInsets.only(right:8),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.symmetric(vertical:15),decoration:BoxDecoration(color:const Color(0xFF111117),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFF20202A))),child:Column(children:[Icon(icon,color:const Color(0xFFAB9FF2)),const SizedBox(height:7),Text(label,style:const TextStyle(fontSize:12,color:Colors.white60))])))));
}
