import 'package:flutter/material.dart';
import 'config.dart';
import 'screens/create_pool_screen.dart';
import 'screens/home_screen.dart';
import 'screens/pools_screen.dart';
import 'services/tx_service.dart';
import 'services/wallet_service.dart';
import 'widgets/connect_button.dart';
import 'widgets/ghost_logo.dart';

void main() => runApp(const GhostLpApp());

class GhostLpApp extends StatelessWidget {
  const GhostLpApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: Config.appName,
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF09090D),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFFAB9FF2),
        brightness: Brightness.dark,
        surface: const Color(0xFF101016),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF09090D),
        elevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF0F0F15),
        indicatorColor: const Color(0xFF2A2740),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF12121A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF20202A)),
        ),
      ),
    ),
    home: const SplashGate(),
  );
}

class SplashGate extends StatefulWidget {
  const SplashGate({super.key});
  @override State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;
  final wallet = WalletService();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850));
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _scale = Tween(begin: .82, end: 1.0).animate(CurvedAnimation(
      parent: _controller, curve: Curves.easeOutBack,
    ));
    _controller.forward();
    _boot();
  }

  Future<void> _boot() async {
    await wallet.restore();
    await Future<void>.delayed(const Duration(milliseconds: 650));
    if (mounted) Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) => Shell(wallet: wallet),
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
      ),
    );
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: FadeTransition(
        opacity: _fade,
        child: ScaleTransition(
          scale: _scale,
          child: Column(mainAxisSize: MainAxisSize.min, children: const [
            GhostLogo(size: 82),
            SizedBox(height: 20),
            Text('GhostLP', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -.8)),
            SizedBox(height: 6),
            Text('Liquidity, without the noise.', style: TextStyle(color: Colors.white38)),
          ]),
        ),
      ),
    ),
  );
}

class Shell extends StatefulWidget {
  final WalletService wallet;
  const Shell({super.key, required this.wallet});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int tab = 0;
  late final TxService tx = TxService(widget.wallet);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.wallet,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          titleSpacing: 18,
          title: const Row(children: [
            GhostLogo(size: 32),
            SizedBox(width: 10),
            Text('GhostLP', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.3)),
          ]),
          actions: [
            if (tab != 0) Padding(
              padding: const EdgeInsets.only(right: 12),
              child: ConnectButton(wallet: widget.wallet),
            ),
          ],
        ),
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          switchInCurve: Curves.easeOutCubic,
          child: IndexedStack(key: ValueKey(tab), index: tab, children: [
            HomeScreen(wallet: widget.wallet, goTab: (i) => setState(() => tab = i)),
            PoolsScreen(wallet: widget.wallet, tx: tx),
            CreatePoolScreen(wallet: widget.wallet, tx: tx),
          ]),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop_rounded), label: 'Pools'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline_rounded), selectedIcon: Icon(Icons.add_circle_rounded), label: 'Create'),
          ],
        ),
      ),
    );
  }
}
