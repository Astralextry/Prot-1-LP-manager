class Config {
  static const appName = 'GhostLP';
  static const appUri = String.fromEnvironment(
    'APP_URI',
    defaultValue: 'https://ghostlp.app',
  );
  static const backendUrl = String.fromEnvironment(
    'BACKEND_URL',
    defaultValue: 'http://10.0.2.2:8787',
  );
  static const rpcUrl = String.fromEnvironment(
    'RPC_URL',
    defaultValue: 'https://api.mainnet-beta.solana.com',
  );
  static const cluster = String.fromEnvironment(
    'SOLANA_CLUSTER',
    defaultValue: 'mainnet-beta',
  );
}
