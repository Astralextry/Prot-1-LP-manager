import 'package:flutter/material.dart';

class GhostLogo extends StatelessWidget {
  final double size;
  const GhostLogo({super.key, this.size = 54});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFFAB9FF2),
        borderRadius: BorderRadius.circular(size * .34),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFAB9FF2).withOpacity(.28),
            blurRadius: size * .38,
            spreadRadius: 1,
          ),
        ],
      ),
      child: CustomPaint(
        painter: _GhostPainter(),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _GhostPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0xFF17151F);
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w*.22, h*.72)
      ..lineTo(w*.22, h*.39)
      ..cubicTo(w*.22,h*.20,w*.36,h*.10,w*.50,h*.10)
      ..cubicTo(w*.64,h*.10,w*.78,h*.20,w*.78,h*.39)
      ..lineTo(w*.78,h*.72)
      ..cubicTo(w*.70,h*.70,w*.65,h*.61,w*.59,h*.70)
      ..cubicTo(w*.53,h*.79,w*.47,h*.79,w*.41,h*.70)
      ..cubicTo(w*.35,h*.61,w*.30,h*.70,w*.22,h*.72)
      ..close();
    canvas.drawPath(path, p);
    final eye = Paint()..color = const Color(0xFFAB9FF2);
    canvas.drawOval(Rect.fromLTWH(w*.34,h*.38,w*.10,h*.13), eye);
    canvas.drawOval(Rect.fromLTWH(w*.56,h*.38,w*.10,h*.13), eye);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
