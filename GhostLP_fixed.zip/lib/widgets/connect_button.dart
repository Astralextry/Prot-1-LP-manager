import 'package:flutter/material.dart';
import '../services/wallet_service.dart';

class ConnectButton extends StatelessWidget {
  final WalletService wallet;
  const ConnectButton({super.key, required this.wallet});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: wallet,
      builder: (ctx, _) {
        if (wallet.connected) {
          final a = wallet.address!;
          return OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFF302D3D)),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.account_balance_wallet_rounded, size: 17),
            label: Text('${a.substring(0, 4)}...${a.substring(a.length - 4)}'),
            onPressed: () async {
              final ok = await showModalBottomSheet<bool>(
                context: ctx,
                showDragHandle: true,
                builder: (sheet) => SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('Wallet connected', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Text('${a.substring(0, 8)}...${a.substring(a.length - 8)}',
                          style: const TextStyle(color: Colors.white54)),
                      const SizedBox(height: 20),
                      SizedBox(width: double.infinity, child: OutlinedButton(
                        onPressed: () => Navigator.pop(sheet, true),
                        child: const Text('Disconnect wallet'),
                      )),
                    ]),
                  ),
                ),
              );
              if (ok == true) await wallet.disconnect();
            },
          );
        }
        return FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFFAB9FF2),
            foregroundColor: const Color(0xFF17151F),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: wallet.connecting ? null : () async {
            await wallet.connect();
            if (wallet.error != null && ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(
                SnackBar(content: Text(wallet.error!)),
              );
            }
          },
          child: wallet.connecting
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Connect wallet', style: TextStyle(fontWeight: FontWeight.w700)),
        );
      },
    );
  }
}
