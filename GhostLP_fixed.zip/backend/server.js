import express from 'express';
import cors from 'cors';
import { PublicKey } from '@solana/web3.js';
import { buildCreatePool, buildAddLiquidity, buildRemoveLiquidity } from './raydium_builder.js';

const app = express();
app.use(cors());
app.use(express.json({ limit: '64kb' }));

const PORT = Number(process.env.PORT || 8787);
const RPC_URL = process.env.RPC_URL || 'https://api.mainnet-beta.solana.com';
const addressLike = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

function bad(res, message, code = 400) { return res.status(code).json({ error: message }); }
function requireBody(body, keys) {
  for (const key of keys) if (body?.[key] === undefined || body[key] === '') return `Missing ${key}`;
  return null;
}
function validAddress(value) {
  if (!addressLike.test(String(value))) return false;
  try { new PublicKey(value); return true; } catch { return false; }
}
function respondBuild(res, result) {
  return res.status(200).json(result);
}

app.get('/health', (_req, res) => res.json({
  ok: true,
  service: 'ghostlp-backend',
  rpcConfigured: Boolean(RPC_URL),
  builders: { raydiumCpmm: true, orcaWhirlpool: false },
}));

app.post('/v1/pools/create', async (req, res) => {
  const missing = requireBody(req.body, ['wallet', 'dex', 'mintA', 'mintB', 'amountA', 'amountB', 'feeTier']);
  if (missing) return bad(res, missing);
  const { wallet, dex, mintA, mintB, amountA, amountB, feeTier, startTime } = req.body;
  if (!validAddress(wallet)) return bad(res, 'Invalid Solana wallet address');
  if (!['raydium', 'orca'].includes(dex)) return bad(res, 'Unsupported DEX');
  if (!validAddress(mintA) || !validAddress(mintB) || mintA === mintB) return bad(res, 'Invalid or duplicate token mint');
  if (!Number.isFinite(Number(amountA)) || Number(amountA) <= 0 || !Number.isFinite(Number(amountB)) || Number(amountB) <= 0) {
    return bad(res, 'Amounts must be positive numbers');
  }
  if (startTime != null && (!Number.isInteger(Number(startTime)) || Number(startTime) < 0)) return bad(res, 'Invalid startTime');
  if (dex === 'orca') return bad(res, 'Orca Whirlpool transaction building is not enabled in this backend yet.', 501);
  try {
    return respondBuild(res, await buildCreatePool({ wallet, mintA, mintB, amountA, amountB, feeTier, startTime }));
  } catch (e) {
    return bad(res, e?.message || 'Failed to build Raydium pool transaction', 422);
  }
});

app.post('/v1/liquidity/add', async (req, res) => {
  const missing = requireBody(req.body, ['wallet', 'dex', 'poolId', 'amountA', 'amountB']);
  if (missing) return bad(res, missing);
  const { wallet, dex, poolId, amountA } = req.body;
  if (!validAddress(wallet)) return bad(res, 'Invalid Solana wallet address');
  if (!validAddress(poolId)) return bad(res, 'Invalid pool address');
  if (dex !== 'raydium') return bad(res, 'Orca Whirlpool liquidity building is not enabled in this backend yet.', 501);
  if (!Number.isFinite(Number(amountA)) || Number(amountA) <= 0) return bad(res, 'Amount must be positive');
  try {
    return respondBuild(res, await buildAddLiquidity({ wallet, poolId, amountA }));
  } catch (e) {
    return bad(res, e?.message || 'Failed to build Raydium add-liquidity transaction', 422);
  }
});

app.post('/v1/liquidity/remove', async (req, res) => {
  const missing = requireBody(req.body, ['wallet', 'dex', 'poolId', 'percent']);
  if (missing) return bad(res, missing);
  const { wallet, dex, poolId, percent } = req.body;
  const pct = Number(percent);
  if (!validAddress(wallet)) return bad(res, 'Invalid Solana wallet address');
  if (!validAddress(poolId)) return bad(res, 'Invalid pool address');
  if (dex !== 'raydium') return bad(res, 'Orca Whirlpool liquidity building is not enabled in this backend yet.', 501);
  if (!Number.isInteger(pct) || pct < 1 || pct > 100) return bad(res, 'Percent must be 1-100');
  try {
    return respondBuild(res, await buildRemoveLiquidity({ wallet, poolId, percent: pct }));
  } catch (e) {
    return bad(res, e?.message || 'Failed to build Raydium remove-liquidity transaction', 422);
  }
});

app.listen(PORT, () => console.log(`GhostLP backend listening on :${PORT}`));
