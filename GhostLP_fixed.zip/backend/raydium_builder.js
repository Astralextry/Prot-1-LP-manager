import {
  Raydium,
  TxVersion,
  DEVNET_PROGRAM_ID,
  CREATE_CPMM_POOL_PROGRAM,
  CREATE_CPMM_POOL_FEE_ACC,
  getCpmmPdaAmmConfigId,
  Percent,
} from '@raydium-io/raydium-sdk-v2';
import { Connection, PublicKey } from '@solana/web3.js';
import BN from 'bn.js';
import Decimal from 'decimal.js';

const connection = new Connection(
  process.env.RPC_URL || 'https://api.mainnet-beta.solana.com',
  'confirmed',
);

const cluster = (process.env.SOLANA_CLUSTER || 'mainnet-beta') === 'devnet' ? 'devnet' : 'mainnet';
const txVersion = TxVersion.V0;

function ownerProxy(address) {
  // Raydium's SDK expects a Keypair-shaped owner while building transactions.
  // We intentionally provide only the public key. execute()/signing is never called here.
  return { publicKey: new PublicKey(address), secretKey: new Uint8Array(64) };
}

async function sdkFor(wallet) {
  return Raydium.load({
    owner: ownerProxy(wallet),
    connection,
    cluster,
    disableFeatureCheck: true,
    disableLoadToken: false,
    blockhashCommitment: 'confirmed',
    ...(cluster === 'devnet' ? {
      urlConfigs: {
        BASE_HOST: 'https://api-v3-devnet.raydium.io',
        OWNER_BASE_HOST: 'https://owner-v1-devnet.raydium.io',
        SWAP_HOST: 'https://transaction-v1-devnet.raydium.io',
      },
    } : {}),
  });
}

function toAtomic(ui, decimals) {
  const value = new Decimal(String(ui));
  if (!value.isFinite() || value.lte(0)) throw new Error('Amount must be positive');
  return new BN(value.mul(new Decimal(10).pow(decimals)).toFixed(0));
}

function serializeOne(tx) {
  if (!tx || typeof tx.serialize !== 'function') {
    throw new Error('Raydium did not return a serializable transaction');
  }
  return Buffer.from(tx.serialize()).toString('base64');
}

function serializeBuilt(result) {
  if (result?.transaction) return [serializeOne(result.transaction)];
  if (Array.isArray(result?.transactions)) return result.transactions.map(serializeOne);
  throw new Error('Raydium transaction builder returned no transaction');
}

function pickFeeConfig(configs, feeTier) {
  const requested = Number(feeTier);
  if (!Number.isFinite(requested)) throw new Error('Invalid Raydium fee tier');
  // UI sends percentage, e.g. 0.25. Raydium stores trade fee in 1e-6 units.
  const target = Math.round(requested * 10000);
  const exact = configs.find(c => Number(c.tradeFeeRate) === target);
  if (exact) return exact;
  // Also accept a config index for future clients.
  const byIndex = configs.find(c => Number(c.index) === Math.round(requested));
  if (byIndex) return byIndex;
  throw new Error(`No Raydium CPMM fee configuration matches ${feeTier}%`);
}

export async function buildCreatePool({ wallet, mintA, mintB, amountA, amountB, feeTier, startTime }) {
  const raydium = await sdkFor(wallet);
  const tokenA = await raydium.token.getTokenInfo(mintA);
  const tokenB = await raydium.token.getTokenInfo(mintB);
  const configs = await raydium.api.getCpmmConfigs();
  if (cluster === 'devnet') {
    for (const c of configs) {
      c.id = getCpmmPdaAmmConfigId(DEVNET_PROGRAM_ID.CREATE_CPMM_POOL_PROGRAM, c.index).publicKey.toBase58();
    }
  }
  const feeConfig = pickFeeConfig(configs, feeTier);
  const programId = cluster === 'devnet' ? DEVNET_PROGRAM_ID.CREATE_CPMM_POOL_PROGRAM : CREATE_CPMM_POOL_PROGRAM;
  const poolFeeAccount = cluster === 'devnet' ? DEVNET_PROGRAM_ID.CREATE_CPMM_POOL_FEE_ACC : CREATE_CPMM_POOL_FEE_ACC;

  const { transaction, transactions, extInfo } = await raydium.cpmm.createPool({
    programId,
    poolFeeAccount,
    mintA: tokenA,
    mintB: tokenB,
    mintAAmount: toAtomic(amountA, tokenA.decimals),
    mintBAmount: toAtomic(amountB, tokenB.decimals),
    startTime: new BN(startTime == null ? 0 : Number(startTime)),
    feeConfig,
    associatedOnly: false,
    ownerInfo: { useSOLBalance: true },
    txVersion,
  });

  const txs = serializeBuilt({ transaction, transactions });
  const poolId = extInfo?.address?.poolId?.toString?.() || extInfo?.address?.ammId?.toString?.();
  return {
    transactions: txs,
    transaction: txs[0],
    metadata: { dex: 'raydium', type: 'cpmm-create', poolId: poolId || null },
  };
}

async function getPool(raydium, poolId) {
  if (cluster === 'mainnet') {
    const data = await raydium.api.fetchPoolById({ ids: poolId });
    if (!data?.length) throw new Error('Raydium pool not found');
    return { poolInfo: data[0], poolKeys: undefined };
  }
  const data = await raydium.cpmm.getPoolInfoFromRpc(poolId);
  return { poolInfo: data.poolInfo, poolKeys: data.poolKeys };
}

export async function buildAddLiquidity({ wallet, poolId, amountA }) {
  const raydium = await sdkFor(wallet);
  const { poolInfo, poolKeys } = await getPool(raydium, poolId);
  const inputAmount = toAtomic(amountA, poolInfo.mintA.decimals);
  const slippage = new Percent(1, 100); // 1%
  const built = await raydium.cpmm.addLiquidity({
    poolInfo,
    poolKeys,
    inputAmount,
    slippage,
    baseIn: true,
    txVersion,
    ownerInfo: { useSOLBalance: true },
  });
  const txs = serializeBuilt(built);
  return { transactions: txs, transaction: txs[0], metadata: { dex: 'raydium', type: 'cpmm-add', poolId } };
}

async function findLpBalance(wallet, mint) {
  const owner = new PublicKey(wallet);
  const response = await connection.getParsedTokenAccountsByOwner(owner, { mint: new PublicKey(mint) });
  let total = 0n;
  for (const item of response.value) {
    const amount = item.account.data.parsed?.info?.tokenAmount?.amount;
    if (amount) total += BigInt(amount);
  }
  return new BN(total.toString());
}

export async function buildRemoveLiquidity({ wallet, poolId, percent }) {
  const raydium = await sdkFor(wallet);
  const { poolInfo, poolKeys } = await getPool(raydium, poolId);
  if (!poolInfo.mintLp?.address) throw new Error('Pool does not expose an LP mint');
  const balance = await findLpBalance(wallet, poolInfo.mintLp.address);
  const lpAmount = balance.mul(new BN(String(percent))).div(new BN('100'));
  if (lpAmount.isZero()) throw new Error('No LP balance available for this pool');
  const built = await raydium.cpmm.withdrawLiquidity({
    poolInfo,
    poolKeys,
    lpAmount,
    slippage: new Percent(1, 100),
    txVersion,
    ownerInfo: { useSOLBalance: true },
  });
  const txs = serializeBuilt(built);
  return { transactions: txs, transaction: txs[0], metadata: { dex: 'raydium', type: 'cpmm-remove', poolId, percent } };
}
