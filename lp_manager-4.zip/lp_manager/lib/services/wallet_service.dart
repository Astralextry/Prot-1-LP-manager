import 'package:flutter/widgets.dart';
import 'package:reown_appkit/reown_appkit.dart';
import '../config.dart';

/// WalletConnect (Reown AppKit) wallet session for Solana.
/// Kept behind this small class so it can be swapped for Solana Mobile
/// Wallet Adapter later without touching the UI.
class WalletService extends ChangeNotifier {
  late final ReownAppKitModal modal;
  bool ready = false;

  Future<void> init(BuildContext context) async {
    modal = ReownAppKitModal(
      context: context,
      projectId: Config.reownProjectId,
      metadata: const PairingMetadata(
        name: 'LP Manager',
        description: 'Manage Solana liquidity pools',
        url: 'https://example.com',
        icons: [],
        redirect: Redirect(native: 'lpmanager://', universal: 'https://example.com'),
      ),
      optionalNamespaces: {
        'solana': RequiredNamespace(
          chains: [Config.solanaChainId],
          methods: ['solana_signTransaction', 'solana_signMessage'],
          events: [],
        ),
      },
    );
    await modal.init();
    modal.addListener(notifyListeners);
    ready = true;
    notifyListeners();
  }

  bool get connected => ready && modal.isConnected;

  String? get address {
    if (!ready) return null;
    final accts = modal.session?.getAccounts();
    if (accts == null || accts.isEmpty) return null;
    final a = accts.firstWhere((x) => x.startsWith('solana:'), orElse: () => accts.first);
    return a.split(':').last;
  }

  /// Asks the wallet to sign a base64 transaction. Returns the raw wallet response.
  Future<dynamic> requestSignature(String base64Tx) {
    return modal.request(
      topic: modal.session!.topic,
      chainId: Config.solanaChainId,
      request: SessionRequestParams(
        method: 'solana_signTransaction',
        params: {'transaction': base64Tx},
      ),
    );
  }
}
