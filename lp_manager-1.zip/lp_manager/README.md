# LP Manager (Flutter, Solana: Raydium + Orca)

## Status
- Works (once you can build): browse/search/sort Raydium + Orca pools, connect wallet via WalletConnect.
- Needs the backend: create pool / add / remove liquidity. The app calls these endpoints and
  expects `{ "transaction": "<base64 unsigned tx, fee payer = owner>" }`:
  - POST /tx/create-pool      { dex, mintA, mintB, amountA, amountB, feeTier, owner }
  - POST /tx/add-liquidity    { dex, poolId, amountA, amountB, owner }
  - POST /tx/remove-liquidity { dex, poolId, percent, owner }
  Raydium and Orca ship TypeScript SDKs, not Dart, so a small Node service builds the instructions.
- NOT compiled or tested here (no Flutter SDK in my sandbox). Expect small fixes.
  The WalletConnect calls and the Orca API field mapping are the first things to check.

## Run
1. Get a project id at https://dashboard.reown.com
2. `flutter create . --platforms=android` (generates the android/ folder), then `flutter pub get`
3. `flutter run --dart-define=REOWN_PROJECT_ID=xxx --dart-define=RPC_URL=https://your-rpc`
4. AndroidManifest.xml: add `<uses-permission android:name="android.permission.INTERNET"/>` and, inside
   `<manifest>`, a `<queries>` block with `<package android:name="app.phantom"/>` and
   `<package android:name="com.solflare.mobile"/>` so wallets can be detected.

## Safety
Real funds. Test on devnet or with tiny amounts first; the app never holds keys, the wallet signs everything.
