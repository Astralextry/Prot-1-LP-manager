import 'package:flutter/material.dart';
import 'package:reown_appkit/reown_appkit.dart';
import 'screens/create_pool_screen.dart';
import 'screens/pools_screen.dart';
import 'services/tx_service.dart';
import 'services/wallet_service.dart';

void main() => runApp(const LpApp());

class LpApp extends StatelessWidget {
  const LpApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'LP Manager',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF6C5CE7),
          brightness: Brightness.dark,
        ),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  final wallet = WalletService();
  late final tx = TxService(wallet);
  int tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => wallet.init(context));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: wallet,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          title: const Text('LP Manager'),
          actions: [
            if (wallet.ready)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: AppKitModalConnectButton(appKit: wallet.modal, size: BaseButtonSize.small),
              ),
          ],
        ),
        body: IndexedStack(index: tab, children: [
          PoolsScreen(wallet: wallet, tx: tx),
          CreatePoolScreen(wallet: wallet, tx: tx),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.water_drop_outlined), label: 'Pools'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'Create'),
          ],
        ),
      ),
    );
  }
}
