import 'package:flutter/material.dart';
import '../services/tx_service.dart';
import '../services/wallet_service.dart';

class CreatePoolScreen extends StatefulWidget {
  final WalletService wallet;
  final TxService tx;
  const CreatePoolScreen({super.key, required this.wallet, required this.tx});
  @override
  State<CreatePoolScreen> createState() => _CreatePoolScreenState();
}

class _CreatePoolScreenState extends State<CreatePoolScreen> {
  String dex = 'raydium';
  final mintA = TextEditingController(text: 'So11111111111111111111111111111111111111112');
  final mintB = TextEditingController(text: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v');
  final amtA = TextEditingController(), amtB = TextEditingController();
  final fee = TextEditingController(text: '0.25');
  bool busy = false;

  Widget _f(TextEditingController c, String label, {bool num = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
            keyboardType: num ? const TextInputType.numberWithOptions(decimal: true) : null),
      );

  Future<void> _submit() async {
    final m = ScaffoldMessenger.of(context);
    if (!widget.wallet.connected) {
      m.showSnackBar(const SnackBar(content: Text('Connect your wallet first')));
      return;
    }
    setState(() => busy = true);
    try {
      final sig = await widget.tx.createPool(
          dex: dex, mintA: mintA.text.trim(), mintB: mintB.text.trim(),
          amountA: amtA.text, amountB: amtB.text, feeTier: fee.text);
      m.showSnackBar(SnackBar(content: Text('Pool created. Tx: ${sig.substring(0, 12)}...')));
    } catch (e) {
      m.showSnackBar(SnackBar(content: Text('$e')));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'raydium', label: Text('Raydium')),
          ButtonSegment(value: 'orca', label: Text('Orca')),
        ],
        selected: {dex},
        onSelectionChanged: (s) => setState(() => dex = s.first),
      ),
      const SizedBox(height: 16),
      _f(mintA, 'Token A mint'),
      _f(mintB, 'Token B mint'),
      _f(amtA, 'Initial amount A', num: true),
      _f(amtB, 'Initial amount B', num: true),
      _f(fee, 'Fee tier (%)', num: true),
      const Text('The initial price is set by the ratio of A to B. '
          'Creating a pool costs SOL for rent and fees, and a bad ratio can be arbitraged instantly.',
          style: TextStyle(fontSize: 12)),
      const SizedBox(height: 16),
      FilledButton(onPressed: busy ? null : _submit,
          child: busy ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Create pool')),
    ]);
  }
}
