import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../config.dart';
import 'wallet_service.dart';

/// Flow: backend builds an UNSIGNED tx (fee payer = user) -> wallet signs via
/// WalletConnect -> app submits to Solana RPC. Private keys never touch the app.
class TxService {
  final WalletService wallet;
  final http.Client _c = http.Client();
  TxService(this.wallet);

  Future<String> _build(String path, Map<String, dynamic> body) async {
    final owner = wallet.address;
    if (owner == null) throw Exception('Connect a wallet first');
    final r = await _c.post(
      Uri.parse('${Config.backendUrl}$path'),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({...body, 'owner': owner}),
    );
    if (r.statusCode != 200) throw Exception('Backend error: ${r.body}');
    return jsonDecode(r.body)['transaction'] as String; // base64, unsigned
  }

  Future<String> createPool({
    required String dex, required String mintA, required String mintB,
    required String amountA, required String amountB, required String feeTier,
  }) async {
    final tx = await _build('/tx/create-pool', {
      'dex': dex, 'mintA': mintA, 'mintB': mintB,
      'amountA': amountA, 'amountB': amountB, 'feeTier': feeTier,
    });
    return signAndSend(tx);
  }

  Future<String> addLiquidity({
    required String dex, required String poolId,
    required String amountA, required String amountB,
  }) async {
    final tx = await _build('/tx/add-liquidity', {
      'dex': dex, 'poolId': poolId, 'amountA': amountA, 'amountB': amountB,
    });
    return signAndSend(tx);
  }

  Future<String> removeLiquidity({
    required String dex, required String poolId, required int percent,
  }) async {
    final tx = await _build('/tx/remove-liquidity',
        {'dex': dex, 'poolId': poolId, 'percent': percent});
    return signAndSend(tx);
  }

  Future<String> signAndSend(String unsignedB64) async {
    final res = await wallet.requestSignature(unsignedB64);
    final m = res is Map ? res : const {};
    final Uint8List signed;
    if (m['transaction'] != null) {
      signed = base64Decode(m['transaction'] as String);
    } else if (m['signature'] != null) {
      // Some wallets return only the signature: place it in slot 0 (fee payer).
      final bytes = Uint8List.fromList(base64Decode(unsignedB64));
      bytes.setRange(1, 65, _base58Decode(m['signature'] as String)); // byte 0 = sig count
      signed = bytes;
    } else {
      throw Exception('Wallet returned no signature');
    }
    final r = await _c.post(
      Uri.parse(Config.rpcUrl),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({
        'jsonrpc': '2.0', 'id': 1, 'method': 'sendTransaction',
        'params': [base64Encode(signed), {'encoding': 'base64', 'preflightCommitment': 'confirmed'}],
      }),
    );
    final j = jsonDecode(r.body);
    if (j['error'] != null) throw Exception(j['error']['message']);
    return j['result'] as String; // tx signature
  }
}

const _alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

Uint8List _base58Decode(String s) {
  var n = BigInt.zero;
  for (final ch in s.split('')) {
    final i = _alphabet.indexOf(ch);
    if (i < 0) throw const FormatException('Bad base58');
    n = n * BigInt.from(58) + BigInt.from(i);
  }
  final out = <int>[];
  while (n > BigInt.zero) {
    out.insert(0, (n & BigInt.from(255)).toInt());
    n >>= 8;
  }
  final zeros = s.split('').takeWhile((c) => c == '1').length;
  final res = Uint8List.fromList([...List.filled(zeros, 0), ...out]);
  if (res.length != 64) throw const FormatException('Signature must be 64 bytes');
  return res;
}
