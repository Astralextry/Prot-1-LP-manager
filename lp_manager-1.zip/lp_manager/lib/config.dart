/// Pass at build time:
/// flutter run --dart-define=REOWN_PROJECT_ID=xxx --dart-define=BACKEND_URL=https://... --dart-define=RPC_URL=https://...
class Config {
  static const reownProjectId = String.fromEnvironment('REOWN_PROJECT_ID');
  // 10.0.2.2 = host machine from the Android emulator
  static const backendUrl =
      String.fromEnvironment('BACKEND_URL', defaultValue: 'http://10.0.2.2:8787');
  // Public RPC is rate limited; use Helius/QuickNode/etc. for real use.
  static const rpcUrl =
      String.fromEnvironment('RPC_URL', defaultValue: 'https://api.mainnet-beta.solana.com');
  static const solanaChainId = 'solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp'; // mainnet
}
