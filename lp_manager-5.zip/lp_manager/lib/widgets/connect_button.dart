import 'package:flutter/material.dart';
import '../services/wallet_service.dart';

class ConnectButton extends StatelessWidget {
  final WalletService wallet;
  const ConnectButton({super.key, required this.wallet});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: wallet,
      builder: (ctx, _) {
        if (wallet.connected) {
          final a = wallet.address!;
          return OutlinedButton.icon(
            icon: const Icon(Icons.account_balance_wallet_outlined, size: 18),
            label: Text('${a.substring(0, 4)}...${a.substring(a.length - 4)}'),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: ctx,
                builder: (d) => AlertDialog(
                  title: const Text('Disconnect wallet?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Disconnect')),
                  ],
                ),
              );
              if (ok == true) wallet.disconnect();
            },
          );
        }
        return FilledButton(
          onPressed: wallet.connecting
              ? null
              : () async {
                  await wallet.connect();
                  if (wallet.error != null && ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text(wallet.error!)));
                  }
                },
          child: wallet.connecting
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Connect wallet'),
        );
      },
    );
  }
}
