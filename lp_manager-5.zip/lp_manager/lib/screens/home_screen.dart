import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/balance_service.dart';
import '../services/wallet_service.dart';
import '../widgets/connect_button.dart';

class HomeScreen extends StatefulWidget {
  final WalletService wallet;
  final void Function(int) goTab;
  const HomeScreen({super.key, required this.wallet, required this.goTab});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final svc = BalanceService();
  Portfolio? portfolio;
  String? error, _loadedFor;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    widget.wallet.addListener(_maybeLoad);
    _maybeLoad();
  }

  @override
  void dispose() {
    widget.wallet.removeListener(_maybeLoad);
    super.dispose();
  }

  void _maybeLoad() {
    final a = widget.wallet.address;
    if (a == _loadedFor) return;
    _loadedFor = a;
    if (a == null) {
      setState(() => portfolio = null);
    } else {
      _refresh();
    }
  }

  Future<void> _refresh() async {
    final a = widget.wallet.address;
    if (a == null) return;
    setState(() { loading = true; error = null; });
    try {
      portfolio = await svc.load(a);
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  String _money(double v) => '\$${v.toStringAsFixed(2).replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',')}';

  @override
  Widget build(BuildContext context) {
    final addr = widget.wallet.address;
    final cs = Theme.of(context).colorScheme;
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          if (addr == null) ...[
            const SizedBox(height: 60),
            Icon(Icons.account_balance_wallet_outlined, size: 64, color: cs.primary),
            const SizedBox(height: 16),
            const Text('Connect your wallet', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('See your balance and manage liquidity pools on Raydium and Orca.',
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            Center(child: ConnectButton(wallet: widget.wallet)),
          ] else ...[
            Row(children: [
              CircleAvatar(radius: 18, backgroundColor: cs.primary,
                  child: const Icon(Icons.person, size: 20, color: Colors.white)),
              const SizedBox(width: 10),
              Text('${addr.substring(0, 4)}...${addr.substring(addr.length - 4)}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const Spacer(),
              IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh)),
            ]),
            const SizedBox(height: 20),
            Center(
              child: loading && portfolio == null
                  ? const Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())
                  : Text(_money(portfolio?.total ?? 0),
                      style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
            ),
            if (error != null)
              Padding(padding: const EdgeInsets.only(top: 8),
                  child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent))),
            const SizedBox(height: 24),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              _Action(Icons.qr_code_2, 'Receive', () => _receive(addr)),
              _Action(Icons.water_drop_outlined, 'Pools', () => widget.goTab(1)),
              _Action(Icons.add_circle_outline, 'Create', () => widget.goTab(2)),
              _Action(Icons.refresh, 'Refresh', _refresh),
            ]),
            const SizedBox(height: 24),
            for (final h in portfolio?.holdings ?? const <Holding>[])
              Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFF1A1D26), borderRadius: BorderRadius.circular(18)),
                child: Row(children: [
                  CircleAvatar(backgroundColor: cs.primary.withOpacity(.25),
                      child: Text(h.symbol.isEmpty ? '?' : h.symbol[0])),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(h.symbol, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    Text('${h.amount.toStringAsFixed(h.amount < 1 ? 4 : 2)} ${h.symbol}',
                        style: const TextStyle(color: Colors.white54, fontSize: 12)),
                  ])),
                  Text(_money(h.usd), style: const TextStyle(fontWeight: FontWeight.w700)),
                ]),
              ),
          ],
        ],
      ),
    );
  }

  void _receive(String addr) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Your Solana address', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 12),
          SelectableText(addr, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(
            icon: const Icon(Icons.copy),
            label: const Text('Copy'),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: addr));
              Navigator.pop(ctx);
            },
          ),
        ]),
      ),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Action(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: 76, padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(color: const Color(0xFF1A1D26), borderRadius: BorderRadius.circular(18)),
          child: Column(children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ]),
        ),
      );
}
