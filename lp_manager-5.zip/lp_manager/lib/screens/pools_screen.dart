import 'package:flutter/material.dart';
import '../models/pool.dart';
import '../services/pool_api.dart';
import '../services/tx_service.dart';
import '../services/wallet_service.dart';

class PoolsScreen extends StatefulWidget {
  final WalletService wallet;
  final TxService tx;
  const PoolsScreen({super.key, required this.wallet, required this.tx});
  @override
  State<PoolsScreen> createState() => _PoolsScreenState();
}

class _PoolsScreenState extends State<PoolsScreen> {
  final api = PoolApi();
  List<Pool> pools = [];
  bool loading = true;
  String? error;
  Dex? filter;
  String query = '';
  String sort = 'tvl';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final res = await Future.wait([api.raydium(), api.orca()]);
      pools = [...res[0], ...res[1]];
    } catch (e) {
      error = '$e';
    }
    if (mounted) setState(() => loading = false);
  }

  List<Pool> get visible {
    final q = query.toLowerCase();
    final l = pools.where((p) =>
        (filter == null || p.dex == filter) &&
        (q.isEmpty || p.pair.toLowerCase().contains(q) || p.id.toLowerCase() == q)).toList();
    l.sort((a, b) => switch (sort) {
          'apr' => b.apr24h.compareTo(a.apr24h),
          'vol' => b.volume24h.compareTo(a.volume24h),
          _ => b.tvl.compareTo(a.tvl),
        });
    return l;
  }

  String _usd(double v) => v >= 1e9 ? '\$${(v / 1e9).toStringAsFixed(2)}B'
      : v >= 1e6 ? '\$${(v / 1e6).toStringAsFixed(2)}M'
      : v >= 1e3 ? '\$${(v / 1e3).toStringAsFixed(1)}K' : '\$${v.toStringAsFixed(0)}';

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: TextField(
          decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search), hintText: 'Search pair (SOL, USDC...)',
              border: OutlineInputBorder(), isDense: true),
          onChanged: (v) => setState(() => query = v),
        ),
      ),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          for (final (label, d) in [('All', null), ('Raydium', Dex.raydium), ('Orca', Dex.orca)])
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ChoiceChip(label: Text(label), selected: filter == d,
                  onSelected: (_) => setState(() => filter = d)),
            ),
          const SizedBox(width: 8),
          for (final (label, k) in [('TVL', 'tvl'), ('APR', 'apr'), ('Volume', 'vol')])
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ChoiceChip(label: Text(label), selected: sort == k,
                  onSelected: (_) => setState(() => sort = k)),
            ),
        ]),
      ),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      FilledButton(onPressed: load, child: const Text('Retry')),
                    ])))
                : RefreshIndicator(
                    onRefresh: load,
                    child: ListView.separated(
                      itemCount: visible.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = visible[i];
                        return ListTile(
                          title: Text(p.pair),
                          subtitle: Text('${p.dexName} · ${p.type} · fee ${p.feePct.toStringAsFixed(2)}%'),
                          trailing: Column(mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text('TVL ${_usd(p.tvl)}'),
                            Text('APR ${p.apr24h.toStringAsFixed(1)}%',
                                style: const TextStyle(color: Colors.greenAccent)),
                          ]),
                          onTap: () => _detail(p),
                        );
                      },
                    ),
                  ),
      ),
    ]);
  }

  void _detail(Pool p) {
    final a = TextEditingController(), b = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(p.pair, style: Theme.of(ctx).textTheme.titleLarge),
          Text('${p.dexName} · ${p.type}'),
          const SizedBox(height: 8),
          Text('TVL ${_usd(p.tvl)}   Vol 24h ${_usd(p.volume24h)}   APR ${p.apr24h.toStringAsFixed(1)}%'),
          const SizedBox(height: 12),
          TextField(controller: a, keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Amount ${p.symbolA}', border: const OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: b, keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Amount ${p.symbolB}', border: const OutlineInputBorder())),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: FilledButton(
              onPressed: () => _run(ctx, () => widget.tx.addLiquidity(
                  dex: p.dex.name, poolId: p.id, amountA: a.text, amountB: b.text)),
              child: const Text('Add liquidity'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(
              onPressed: () => _run(ctx, () => widget.tx.removeLiquidity(
                  dex: p.dex.name, poolId: p.id, percent: 100)),
              child: const Text('Remove all'))),
          ]),
        ]),
      ),
    );
  }

  Future<void> _run(BuildContext sheet, Future<String> Function() action) async {
    final messenger = ScaffoldMessenger.of(context);
    if (!widget.wallet.connected) {
      messenger.showSnackBar(const SnackBar(content: Text('Connect your wallet first')));
      return;
    }
    Navigator.pop(sheet);
    try {
      final sig = await action();
      messenger.showSnackBar(SnackBar(content: Text('Sent: ${sig.substring(0, 12)}...')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('$e')));
    }
  }
}
