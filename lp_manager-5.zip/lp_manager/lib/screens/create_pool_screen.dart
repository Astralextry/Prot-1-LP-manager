import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../services/balance_service.dart';
import '../services/tx_service.dart';
import '../services/wallet_service.dart';

class Tok {
  final String symbol, mint;
  const Tok(this.symbol, this.mint);
}

const presets = [
  Tok('SOL', BalanceService.solMint),
  Tok('USDC', 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'),
  Tok('USDT', 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB'),
  Tok('RAY', '4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R'),
];

const _card = Color(0xFF1A1D26);

class CreatePoolScreen extends StatefulWidget {
  final WalletService wallet;
  final TxService tx;
  const CreatePoolScreen({super.key, required this.wallet, required this.tx});
  @override
  State<CreatePoolScreen> createState() => _CreatePoolScreenState();
}

class _CreatePoolScreenState extends State<CreatePoolScreen> {
  final bal = BalanceService();
  String dex = 'raydium';
  String symA = 'SOL', symB = 'USDC';
  final customA = TextEditingController(), customB = TextEditingController();
  final amtA = TextEditingController(), amtB = TextEditingController();
  // Common tiers; the backend validates against the DEX's live configs.
  static const feeTiers = {
    'raydium': ['0.25%', '1%', '0.01%'],
    'orca': ['0.01%', '0.05%', '0.30%', '1.00%'],
  };
  String? fee = '0.25%';
  bool startNow = true;
  DateTime? startAt;
  Map<String, double> balances = {}, prices = {};
  String? _loadedFor;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    widget.wallet.addListener(_loadBalances);
    _loadBalances();
    _loadPrices();
  }

  @override
  void dispose() {
    widget.wallet.removeListener(_loadBalances);
    super.dispose();
  }

  String _mint(String sym, TextEditingController custom) =>
      sym == 'Custom' ? custom.text.trim() : presets.firstWhere((t) => t.symbol == sym).mint;
  String get mintA => _mint(symA, customA);
  String get mintB => _mint(symB, customB);

  Future<void> _loadBalances() async {
    final a = widget.wallet.address;
    if (a == _loadedFor) return;
    _loadedFor = a;
    if (a == null) {
      setState(() => balances = {});
      return;
    }
    try {
      final p = await bal.load(a);
      if (mounted) setState(() => balances = {for (final h in p.holdings) h.mint: h.amount});
    } catch (_) {}
  }

  Future<void> _loadPrices() async {
    final p = await bal.prices([mintA, mintB]);
    if (mounted) setState(() => prices = p);
  }

  void _fill(TextEditingController c, String mint, double frac) {
    var b = balances[mint] ?? 0;
    if (mint == BalanceService.solMint) b = math.max(0.0, b - 0.25); // keep SOL for fees/rent
    c.text = (b * frac).toStringAsFixed(6).replaceFirst(RegExp(r'\.?0+$'), '');
    setState(() {});
  }

  double? get _initPrice {
    final a = double.tryParse(amtA.text), b = double.tryParse(amtB.text);
    return (a == null || b == null || a <= 0 || b <= 0) ? null : b / a;
  }

  double? get _mktPrice {
    final pa = prices[mintA], pb = prices[mintB];
    return (pa == null || pb == null || pa == 0 || pb == 0) ? null : pa / pb;
  }

  String _n(double v) => v >= 100 ? v.toStringAsFixed(2) : v.toStringAsPrecision(6);

  Widget _chip(String t, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: InkWell(
          onTap: f,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(6)),
            child: Text(t, style: const TextStyle(fontSize: 11)),
          ),
        ),
      );

  Widget _tokenBox(String label, String sym, TextEditingController custom,
      TextEditingController amt, void Function(String) onSym) {
    final mint = _mint(sym, custom);
    final b = balances[mint];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(18)),
      child: Column(children: [
        Row(children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          const Spacer(),
          if (b != null) ...[
            Text(_n(b), style: const TextStyle(fontSize: 12, color: Colors.white70)),
            _chip('Max', () => _fill(amt, mint, 1)),
            _chip('50%', () => _fill(amt, mint, .5)),
          ],
        ]),
        Row(children: [
          DropdownButton<String>(
            value: sym,
            underline: const SizedBox(),
            items: [
              for (final t in presets) DropdownMenuItem(value: t.symbol, child: Text(t.symbol, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
              const DropdownMenuItem(value: 'Custom', child: Text('Custom', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
            ],
            onChanged: (v) {
              if (v == null) return;
              onSym(v);
              _loadPrices();
            },
          ),
          Expanded(
            child: TextField(
              controller: amt,
              textAlign: TextAlign.right,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(fontSize: 24),
              decoration: const InputDecoration(border: InputBorder.none, hintText: '0.00'),
              onChanged: (_) => setState(() {}),
            ),
          ),
        ]),
        if (sym == 'Custom')
          TextField(
            controller: custom,
            decoration: const InputDecoration(labelText: 'Token mint address', isDense: true),
            onChanged: (_) => _loadPrices(),
          ),
      ]),
    );
  }

  Future<void> _pickStart() async {
    final d = await showDatePicker(
        context: context, initialDate: DateTime.now(),
        firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t == null) return;
    setState(() { startNow = false; startAt = DateTime(d.year, d.month, d.day, t.hour, t.minute); });
  }

  Future<void> _submit() async {
    final m = ScaffoldMessenger.of(context);
    void say(String s) => m.showSnackBar(SnackBar(content: Text(s)));
    if (!widget.wallet.connected) return say('Connect your wallet first');
    if (mintA.length < 32 || mintB.length < 32) return say('Enter valid token mints');
    if (mintA == mintB) return say('Pick two different tokens');
    if (_initPrice == null) return say('Enter both amounts');
    if (fee == null) return say('Choose a fee tier');
    setState(() => busy = true);
    try {
      final sig = await widget.tx.createPool(
        dex: dex, mintA: mintA, mintB: mintB, amountA: amtA.text, amountB: amtB.text,
        feeTier: fee!.replaceAll('%', ''),
        startTime: startNow || startAt == null ? null : startAt!.millisecondsSinceEpoch ~/ 1000,
      );
      say('Pool created. Tx: ${sig.substring(0, 12)}...');
    } catch (e) {
      say('$e');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final ip = _initPrice, mp = _mktPrice;
    final off = ip != null && mp != null && (ip - mp).abs() / mp > 0.05;
    final tiers = feeTiers[dex]!;
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Initialize pool', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'raydium', label: Text('Raydium')),
          ButtonSegment(value: 'orca', label: Text('Orca')),
        ],
        selected: {dex},
        onSelectionChanged: (s) => setState(() { dex = s.first; fee = feeTiers[dex]!.first; }),
      ),
      const SizedBox(height: 14),
      _tokenBox('Base token', symA, customA, amtA, (v) => setState(() => symA = v)),
      const Padding(padding: EdgeInsets.symmetric(vertical: 6), child: Center(child: Icon(Icons.add_circle, color: Colors.white38))),
      _tokenBox('Quote token', symB, customB, amtB, (v) => setState(() => symB = v)),
      const SizedBox(height: 16),
      const Text('Initial price', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14)),
        child: Text(ip == null ? 'Enter both amounts' : '1 $symA = ${_n(ip)} $symB',
            style: const TextStyle(fontSize: 16)),
      ),
      if (mp != null)
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('Current market price: 1 $symA ≈ ${_n(mp)} $symB',
              style: const TextStyle(color: Colors.lightBlueAccent, fontSize: 12)),
        ),
      if (off)
        const Padding(
          padding: EdgeInsets.only(top: 6),
          child: Text('Your price is more than 5% away from market. Bots will arbitrage the difference and you will lose money.',
              style: TextStyle(color: Colors.orangeAccent, fontSize: 12)),
        ),
      const SizedBox(height: 16),
      const Text('Fee tier', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      DropdownButtonFormField<String>(
        value: tiers.contains(fee) ? fee : tiers.first,
        items: [for (final f in tiers) DropdownMenuItem(value: f, child: Text(f))],
        onChanged: (v) => setState(() => fee = v),
        decoration: const InputDecoration(filled: true, fillColor: _card, border: OutlineInputBorder(borderSide: BorderSide.none)),
      ),
      const SizedBox(height: 16),
      const Text('Start time', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      SegmentedButton<bool>(
        segments: [
          const ButtonSegment(value: true, label: Text('Start now')),
          ButtonSegment(value: false, label: Text(startAt == null ? 'Custom' : '${startAt!.month}/${startAt!.day} ${startAt!.hour}:${startAt!.minute.toString().padLeft(2, '0')}')),
        ],
        selected: {startNow},
        onSelectionChanged: (s) => s.first ? setState(() => startNow = true) : _pickStart(),
      ),
      const SizedBox(height: 12),
      Text(dex == 'raydium'
              ? 'Note: a creation fee of about 0.2 SOL is required for new pools.'
              : 'Note: creating a pool costs SOL for account rent and network fees.',
          style: const TextStyle(color: Colors.amberAccent, fontSize: 12)),
      const SizedBox(height: 16),
      SizedBox(
        height: 50,
        child: FilledButton(
          onPressed: busy ? null : _submit,
          child: busy
              ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Initialize liquidity pool'),
        ),
      ),
    ]);
  }
}
