enum Dex { raydium, orca }

class Pool {
  final Dex dex;
  final String id, symbolA, symbolB, mintA, mintB, type;
  final double tvl, volume24h, apr24h, feePct;

  const Pool({
    required this.dex, required this.id, required this.symbolA, required this.symbolB,
    required this.mintA, required this.mintB, required this.type,
    required this.tvl, required this.volume24h, required this.apr24h, required this.feePct,
  });

  String get pair => '$symbolA / $symbolB';
  String get dexName => dex == Dex.raydium ? 'Raydium' : 'Orca';

  static double _d(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}') ?? 0;
  static String _s(dynamic v, [String fb = '?']) => (v == null || '$v'.isEmpty) ? fb : '$v';

  // Raydium API v3: /pools/info/list
  factory Pool.fromRaydium(Map<String, dynamic> j) {
    final day = (j['day'] as Map?) ?? const {};
    final a = (j['mintA'] as Map?) ?? const {}, b = (j['mintB'] as Map?) ?? const {};
    return Pool(
      dex: Dex.raydium, id: _s(j['id']), type: _s(j['type'], 'Pool'),
      symbolA: _s(a['symbol']), symbolB: _s(b['symbol']),
      mintA: _s(a['address']), mintB: _s(b['address']),
      tvl: _d(j['tvl']), volume24h: _d(day['volume']), apr24h: _d(day['apr']),
      feePct: _d(j['feeRate']) * 100,
    );
  }

  // Orca public API v2: /pools, /pools/search (field names mapped defensively)
  factory Pool.fromOrca(Map<String, dynamic> j) {
    final stats = ((j['stats'] as Map?)?['24h'] as Map?) ?? const {};
    final a = (j['tokenA'] as Map?) ?? const {}, b = (j['tokenB'] as Map?) ?? const {};
    return Pool(
      dex: Dex.orca, id: _s(j['address']), type: 'Whirlpool',
      symbolA: _s(a['symbol']), symbolB: _s(b['symbol']),
      mintA: _s(a['address']), mintB: _s(b['address']),
      tvl: _d(j['tvlUsdc']), volume24h: _d(stats['volume']),
      apr24h: _d(stats['yieldOverTvl']) * 365 * 100, // daily yield fraction -> APR %
      feePct: _d(j['feeRate']) / 10000, // hundredths of a bip -> %
    );
  }
}
