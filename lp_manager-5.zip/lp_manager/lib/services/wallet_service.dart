import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:solana_kit_mobile_wallet_adapter/solana_kit_mobile_wallet_adapter.dart';
import 'package:solana_kit_mobile_wallet_adapter_protocol/solana_kit_mobile_wallet_adapter_protocol.dart';

/// Wallet connection via Solana Mobile Wallet Adapter (MWA).
/// The app talks directly to Phantom/Solflare on the same phone, with no
/// internet relay, so it does not depend on WalletConnect servers.
class WalletService extends ChangeNotifier {
  static const _identity = AppIdentity(name: 'LP Manager');
  static const _chain = 'solana:mainnet';

  String? address;
  String? error;
  bool connecting = false;

  bool get ready => true;
  bool get connected => address != null;

  Future<void> connect() async {
    connecting = true;
    error = null;
    notifyListeners();
    try {
      assertMwaSupported();
      final auth = await transact((wallet) => wallet.authorize(identity: _identity, chain: _chain));
      if (auth.accounts.isEmpty) throw Exception('Wallet returned no account');
      final acct = auth.accounts.first;
      address = _toBase58Address(acct.displayAddress, acct.address);
    } catch (e) {
      error = 'Could not connect. Make sure Phantom or Solflare is installed and set up.\n$e';
    }
    connecting = false;
    notifyListeners();
  }

  void disconnect() {
    address = null;
    notifyListeners();
  }

  /// Sends a base64 unsigned transaction to the wallet; returns the signed base64 transaction.
  Future<String> signTransaction(String unsignedBase64) async {
    final signed = await transact((wallet) async {
      await wallet.authorize(identity: _identity, chain: _chain);
      return wallet.signTransactions(payloads: [unsignedBase64]);
    });
    if (signed.isEmpty) throw Exception('Wallet returned no signed transaction');
    return signed.first;
  }
}

final _b58 = RegExp(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$');
const _alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

/// MWA returns the account as base64 public-key bytes (and sometimes a base58 display address).
String _toBase58Address(String? display, String raw) {
  if (display != null && _b58.hasMatch(display)) return display;
  if (_b58.hasMatch(raw)) return raw;
  final bytes = base64Decode(raw);
  var n = BigInt.zero;
  for (final b in bytes) {
    n = (n << 8) | BigInt.from(b);
  }
  final out = StringBuffer();
  while (n > BigInt.zero) {
    out.write(_alphabet[(n % BigInt.from(58)).toInt()]);
    n ~/= BigInt.from(58);
  }
  final zeros = bytes.takeWhile((b) => b == 0).length;
  return '1' * zeros + out.toString().split('').reversed.join();
}
