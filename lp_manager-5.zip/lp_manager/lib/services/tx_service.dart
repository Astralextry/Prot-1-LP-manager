import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';
import 'wallet_service.dart';

/// Flow: backend builds an UNSIGNED tx (fee payer = user) -> wallet signs via
/// Mobile Wallet Adapter -> app submits to Solana RPC. Keys never touch the app.
class TxService {
  final WalletService wallet;
  final http.Client _c = http.Client();
  TxService(this.wallet);

  Future<String> _build(String path, Map<String, dynamic> body) async {
    final owner = wallet.address;
    if (owner == null) throw Exception('Connect a wallet first');
    final r = await _c.post(
      Uri.parse('${Config.backendUrl}$path'),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({...body, 'owner': owner}),
    );
    if (r.statusCode != 200) throw Exception('Backend error: ${r.body}');
    return jsonDecode(r.body)['transaction'] as String; // base64, unsigned
  }

  Future<String> createPool({
    required String dex, required String mintA, required String mintB,
    required String amountA, required String amountB, required String feeTier,
    int? startTime,
  }) async {
    final tx = await _build('/tx/create-pool', {
      'dex': dex, 'mintA': mintA, 'mintB': mintB,
      'amountA': amountA, 'amountB': amountB, 'feeTier': feeTier,
      if (startTime != null) 'startTime': startTime,
    });
    return signAndSend(tx);
  }

  Future<String> addLiquidity({
    required String dex, required String poolId,
    required String amountA, required String amountB,
  }) async {
    final tx = await _build('/tx/add-liquidity', {
      'dex': dex, 'poolId': poolId, 'amountA': amountA, 'amountB': amountB,
    });
    return signAndSend(tx);
  }

  Future<String> removeLiquidity({
    required String dex, required String poolId, required int percent,
  }) async {
    final tx = await _build('/tx/remove-liquidity',
        {'dex': dex, 'poolId': poolId, 'percent': percent});
    return signAndSend(tx);
  }

  Future<String> signAndSend(String unsignedB64) async {
    final signedB64 = await wallet.signTransaction(unsignedB64);
    final r = await _c.post(
      Uri.parse(Config.rpcUrl),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({
        'jsonrpc': '2.0', 'id': 1, 'method': 'sendTransaction',
        'params': [signedB64, {'encoding': 'base64', 'preflightCommitment': 'confirmed'}],
      }),
    );
    final j = jsonDecode(r.body);
    if (j['error'] != null) throw Exception(j['error']['message']);
    return j['result'] as String; // tx signature
  }
}
