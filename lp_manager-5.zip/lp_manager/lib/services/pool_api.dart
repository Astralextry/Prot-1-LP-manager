import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/pool.dart';

class PoolApi {
  final http.Client _c = http.Client();

  Future<List<Pool>> raydium({int size = 40}) async {
    final r = await _c.get(Uri.https('api-v3.raydium.io', '/pools/info/list', {
      'poolType': 'all', 'poolSortField': 'liquidity', 'sortType': 'desc',
      'pageSize': '$size', 'page': '1',
    }));
    final body = jsonDecode(r.body);
    if (body['success'] != true) throw Exception('Raydium: ${body['msg']}');
    return (body['data']['data'] as List)
        .map((e) => Pool.fromRaydium(Map<String, dynamic>.from(e))).toList();
  }

  Future<List<Pool>> orca({String? query, int size = 40}) async {
    final search = query != null && query.trim().isNotEmpty;
    final uri = search
        ? Uri.https('api.orca.so', '/v2/solana/pools/search', {'q': query.trim()})
        : Uri.https('api.orca.so', '/v2/solana/pools',
            {'sortBy': 'tvl', 'sortDirection': 'desc', 'size': '$size'});
    final r = await _c.get(uri);
    if (r.statusCode != 200) throw Exception('Orca: HTTP ${r.statusCode}');
    final data = jsonDecode(r.body)['data'] as List? ?? [];
    return data.map((e) => Pool.fromOrca(Map<String, dynamic>.from(e))).toList();
  }
}
