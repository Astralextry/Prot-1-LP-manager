import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';

class Holding {
  final String mint, symbol;
  final double amount, price;
  const Holding(this.mint, this.symbol, this.amount, this.price);
  double get usd => amount * price;
}

class Portfolio {
  final List<Holding> holdings;
  const Portfolio(this.holdings);
  double get total => holdings.fold(0, (s, h) => s + h.usd);
}

/// Read-only: wallet balances from a Solana RPC, prices/symbols from Raydium API v3.
class BalanceService {
  static const solMint = 'So11111111111111111111111111111111111111112';
  static const tokenProgram = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
  final http.Client _c = http.Client();

  Future<dynamic> _rpc(String method, List params) async {
    final r = await _c.post(Uri.parse(Config.rpcUrl),
        headers: {'content-type': 'application/json'},
        body: jsonEncode({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}));
    final j = jsonDecode(r.body);
    if (j['error'] != null) throw Exception(j['error']['message']);
    return j['result'];
  }

  Future<Map<String, double>> prices(List<String> mints) async {
    final out = <String, double>{};
    final ids = mints.where((m) => m.length > 30).toList();
    if (ids.isEmpty) return out;
    try {
      final r = await _c.get(Uri.https('api-v3.raydium.io', '/mint/price', {'mints': ids.join(',')}));
      final pr = jsonDecode(r.body);
      if (pr['success'] == true) {
        (pr['data'] as Map).forEach((k, v) => out[k] = double.tryParse('$v') ?? 0);
      }
    } catch (_) {}
    return out;
  }

  Future<Portfolio> load(String owner) async {
    final sol = (await _rpc('getBalance', [owner]))['value'] / 1e9;
    final tok = await _rpc('getTokenAccountsByOwner', [
      owner, {'programId': tokenProgram}, {'encoding': 'jsonParsed'},
    ]);
    final amounts = <String, double>{solMint: (sol as num).toDouble()};
    for (final a in (tok['value'] as List)) {
      final info = a['account']['data']['parsed']['info'];
      final ui = (info['tokenAmount']['uiAmount'] as num?)?.toDouble() ?? 0;
      if (ui > 0) amounts[info['mint']] = (amounts[info['mint']] ?? 0) + ui;
    }
    final mints = amounts.keys.take(50).toList();
    final joined = mints.join(',');
    final prices = <String, double>{};
    final symbols = <String, String>{};
    try {
      final pr = jsonDecode((await _c.get(Uri.https('api-v3.raydium.io', '/mint/price', {'mints': joined}))).body);
      if (pr['success'] == true) {
        (pr['data'] as Map).forEach((k, v) => prices[k] = double.tryParse('$v') ?? 0);
      }
      final md = jsonDecode((await _c.get(Uri.https('api-v3.raydium.io', '/mint/ids', {'mints': joined}))).body);
      if (md['success'] == true) {
        for (final m in (md['data'] as List)) {
          if (m != null) symbols[m['address']] = m['symbol'] ?? '';
        }
      }
    } catch (_) {/* prices are optional */}
    final list = mints.map((m) => Holding(
        m,
        m == solMint ? 'SOL' : ((symbols[m] ?? '').isNotEmpty ? symbols[m]! : '${m.substring(0, 4)}...'),
        amounts[m]!, prices[m] ?? 0)).toList()
      ..sort((a, b) => b.usd.compareTo(a.usd));
    return Portfolio(list);
  }
}
